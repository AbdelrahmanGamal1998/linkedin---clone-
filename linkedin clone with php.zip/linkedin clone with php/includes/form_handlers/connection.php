<?php
$con=mysqli_connect("localhost","root","12345678","mywebsite") or die ("Connection failed to database");
?>